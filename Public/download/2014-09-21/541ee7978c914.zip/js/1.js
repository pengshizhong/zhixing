var box_width = 0;
var box_obj = document.getElementById('slider');
var box_li = document.getElementById('slider').getElementsByTagName("li");
var li_num = box_li.length;

for (var i = 0; i < box_li.length; i++) {
	box_width += 840;
}
box_obj.style.width = box_width + 'px';

var keVar = function(id) {
	return "string" == typeof id ? document.getElementById(id) : id;
};

var Class = {
	create: function() {
		return function() {
			this.initialize.apply(this, arguments);
		}
	}
}

var TransformView = Class.create();
TransformView.prototype = {
	//容器对象,滑动对象,切换参数,切换数量
	initialize: function(container, slider, parameter, count) {
		if (parameter <= 0 || count <= 0) return;
		var oContainer = keVar(news_box),
			oSlider = keVar(slider),
			oThis = this;

		this.Index = 0; //当前索引

		this._timer = null; //定时器
		this._slider = oSlider; //滑动对象
		this._parameter = parameter; //切换参数
		this._count = count || 0; //切换数量
		this._target = 0; //目标参数

		this.Step = 5;
		this.Time = 10;
		this.Pause = 2000;
		this.onStart = function() {};
		this.onFinish = function() {};

		oSlider.style.left = 0;
	},

	//开始切换设置
	Start: function() {
		if (this.Index < 0) {
			this.Index = this._count - 1;
		} else if (this.Index >= this._count) {
			this.Index = 0;
		}

		this._target = -1 * this._parameter * this.Index;
		this.onStart();
		this.Move();
	},
	//移动
	Move: function() {
		clearTimeout(this._timer);
		var oThis = this,
			iNow = parseInt(this._slider.style.left) || 0,
			iStep = this.GetStep(this._target, iNow);

		if (iStep != 0) {
			this._slider.style.left = (iNow + iStep) + "px";
			this._timer = setTimeout(function() {
				oThis.Move();
			}, this.Time);
		} else {
			this._slider.style.left = this._target + "px";
			this.onFinish();
			this._timer = setTimeout(function() {
				oThis.Index++;
				oThis.Start();
			},this.Pause);
		}
	},
	//获取步长
	GetStep: function(iTarget, iNow) {
		var iStep = (iTarget - iNow) / this.Step;
		if (iStep == 0) return 0;
		if (Math.abs(iStep) < 1) return (iStep > 0 ? 1 : -1);
		return iStep;
	},
	//停止
	Stop: function(iTarget, iNow) {
		clearTimeout(this._timer);
		this._slider.style.left = this._target + "px";
	}
};

window.onload = function() {
	function Each(list, fun) {
		for (var i = 0, len = list.length; i < len; i++) {
			fun(list[i], i);
		}
	};

	var objs2 = keVar("tab").getElementsByTagName("li");
	var tv2 = new TransformView("news_box", "slider", 840, li_num, {
		onStart: function() {
			Each(objs2, function(o, i) {
				o.className = tv2.Index == i ? "on" : "off";
			})
		}, //按钮样式
	}); //6是轮播总数
	tv2.Start();
	Each(objs2, function(o, i) {
		o.onmouseover = function() {
			o.className = "on";
			tv2.Index = i;
			tv2.Start();
		}
		o.onmouseout = function() {
			o.className = "off";
			tv2.Start();
		}
	})


}